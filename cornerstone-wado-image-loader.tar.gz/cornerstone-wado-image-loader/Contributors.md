Contributors
============

* [Chris Hafey](https://github.com/chafey) - Design, architecturem, support and implementation
* [rii-mango](https://github.com/rii-mango) for the [JPEGLossless decoder](https://github.com/rii-mango/JPEGLosslessDecoderJS)
* [gSquared](https://github.com/g-squared) for the JPEG lossy decoder, RLE and PALETTE_COLOR support
* [jpambrun](https://github.com/jpambrun) and [pdf.js](https://github.com/mozilla/pdf.js) for the JPEG 2000 decoder
* [jpambrun](https://github.com/jpambrun) and [OpenJPEG](http://www.openjpeg.org/) for another JPEG 2000 decoder
